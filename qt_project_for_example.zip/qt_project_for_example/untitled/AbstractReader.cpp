#include "AbstractReader.h"

AbstractReader::AbstractReader(const string& name):m_f(name){}
